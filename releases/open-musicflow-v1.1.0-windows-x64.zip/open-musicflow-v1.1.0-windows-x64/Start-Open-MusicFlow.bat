@echo off
title Open MusicFlow Studio — LG SJ8 Controller
cd /d "%~dp0"
echo ========================================================
echo   Open MusicFlow Studio — LG SJ8 Controller ^& DMS
echo   Web UI ^& API : http://127.0.0.1:4741
echo   DLNA / DMS   : http://0.0.0.0:49252/dmr.xml
echo ========================================================
start "" cmd /c "timeout /t 1 /nobreak >nul & start msedge --app=http://127.0.0.1:4741 2>nul || start http://127.0.0.1:4741"
node dist-electron\backend\standaloneServer.js
