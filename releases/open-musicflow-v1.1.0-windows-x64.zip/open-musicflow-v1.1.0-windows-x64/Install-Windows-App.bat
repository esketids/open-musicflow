@echo off
setlocal
set "SRC_DIR=%~dp0"
set "DEST_DIR=%LOCALAPPDATA%\OpenMusicFlowStudio"

echo Installing Open MusicFlow Studio to %DEST_DIR% ...
if not exist "%DEST_DIR%" mkdir "%DEST_DIR%"
xcopy /E /I /Y "%SRC_DIR%*" "%DEST_DIR%\" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $desktop = [Environment]::GetFolderPath('Desktop'); ^
   $s1 = $ws.CreateShortcut((Join-Path $desktop 'Open MusicFlow Studio.lnk')); ^
   $s1.TargetPath = Join-Path '%DEST_DIR%' 'Start-Open-MusicFlow.bat'; ^
   $s1.WorkingDirectory = '%DEST_DIR%'; ^
   $s1.Description = 'Open MusicFlow Studio — LG Soundbar & DMS Controller'; ^
   $s1.Save(); ^
   $startMenu = [Environment]::GetFolderPath('Programs'); ^
   $s2 = $ws.CreateShortcut((Join-Path $startMenu 'Open MusicFlow Studio.lnk')); ^
   $s2.TargetPath = Join-Path '%DEST_DIR%' 'Start-Open-MusicFlow.bat'; ^
   $s2.WorkingDirectory = '%DEST_DIR%'; ^
   $s2.Save();"

echo.
echo [OK] Installed Open MusicFlow Studio and created Desktop + Start Menu shortcuts!
echo Launching Open MusicFlow Studio...
start "" "%DEST_DIR%\Start-Open-MusicFlow.bat"
