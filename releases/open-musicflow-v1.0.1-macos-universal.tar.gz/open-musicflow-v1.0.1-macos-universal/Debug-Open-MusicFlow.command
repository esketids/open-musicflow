#!/usr/bin/env bash
set -e
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/miniconda3/bin:$HOME/anaconda3/bin:$HOME/miniforge3/bin:$PATH"
if [ -d "$HOME/.nvm/versions/node" ]; then
  LATEST_NVM="$(ls -1 "$HOME/.nvm/versions/node" 2>/dev/null | tail -n 1)"
  if [ -n "$LATEST_NVM" ]; then
    export PATH="$HOME/.nvm/versions/node/$LATEST_NVM/bin:$PATH"
  fi
fi

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Remove macOS Gatekeeper quarantine attributes if present
xattr -cr "$DIR" 2>/dev/null || true

# Stop any stale previous instance holding port 4741 so the new server takes over cleanly
STALE_PIDS="$(lsof -ti :4741 2>/dev/null || true)"
if [ -n "$STALE_PIDS" ]; then
  echo "Stopping previous server instance on port 4741 (PID: $STALE_PIDS)..."
  kill -9 $STALE_PIDS 2>/dev/null || true
  sleep 0.3
fi

echo "=================================================================="
echo "  Open MusicFlow Studio — LG SJ8 Controller & Live Debug Console"
echo "  Web UI & API : http://127.0.0.1:4741"
echo "  Debug Logs   : http://127.0.0.1:4741/api/debug-log"
echo "  Log Files    : /tmp/open-musicflow-debug.log"
echo "                 ~/Library/Logs/OpenMusicFlowStudio/debug.log"
echo "  DLNA / DMS   : http://0.0.0.0:49252/dmr.xml"
echo "=================================================================="

(
  for _ in {1..25}; do
    if nc -z 127.0.0.1 4741 >/dev/null 2>&1; then
      open "http://127.0.0.1:4741" || true
      break
    fi
    sleep 0.2
  done
) &
exec node "$DIR/dist-electron/backend/standaloneServer.js"
