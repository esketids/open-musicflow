#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "========================================================"
echo "  Open MusicFlow Studio — LG SJ8 Controller & DMS"
echo "  Web UI & API : http://127.0.0.1:4741"
echo "  DLNA / DMS   : http://0.0.0.0:49252/dmr.xml"
echo "========================================================"

(
  sleep 1
  if command -v google-chrome >/dev/null 2>&1; then
    google-chrome --app="http://127.0.0.1:4741" >/dev/null 2>&1 &
  elif command -v chromium >/dev/null 2>&1; then
    chromium --app="http://127.0.0.1:4741" >/dev/null 2>&1 &
  elif command -v brave >/dev/null 2>&1; then
    brave --app="http://127.0.0.1:4741" >/dev/null 2>&1 &
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://127.0.0.1:4741" >/dev/null 2>&1 &
  fi
) &

exec node "$DIR/dist-electron/backend/standaloneServer.js"
