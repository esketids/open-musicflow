#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/share/open-musicflow"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"

mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$APPS_DIR"
cp -r "$DIR/"* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/start-open-musicflow.sh"

ln -sf "$INSTALL_DIR/start-open-musicflow.sh" "$BIN_DIR/open-musicflow"

cat > "$APPS_DIR/open-musicflow.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Open MusicFlow Studio
Comment=LG SJ8 Soundbar Controller, Wi-Fi Alarms, Spotify Connect & DMS Server
Exec=$INSTALL_DIR/start-open-musicflow.sh
Icon=$INSTALL_DIR/icon.svg
Terminal=false
Categories=AudioVideo;Audio;Music;
StartupNotify=true
EOF

chmod +x "$APPS_DIR/open-musicflow.desktop"
update-desktop-database "$APPS_DIR" 2>/dev/null || true

echo "✅ Installed Open MusicFlow Studio to $INSTALL_DIR"
echo "✅ Added desktop launcher to Application Menu (open-musicflow.desktop)"
echo "✅ Added CLI command: ~/.local/bin/open-musicflow"
