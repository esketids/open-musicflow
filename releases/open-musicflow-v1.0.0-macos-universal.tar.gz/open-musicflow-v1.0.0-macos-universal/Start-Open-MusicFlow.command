#!/usr/bin/env bash
set -e
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/miniconda3/bin:$HOME/anaconda3/bin:$HOME/miniforge3/bin:$PATH"
if [ -d "$HOME/.nvm/versions/node" ]; then
  LATEST_NVM="$(ls -1 "$HOME/.nvm/versions/node" 2>/dev/null | tail -n 1)"
  if [ -n "$LATEST_NVM" ]; then
    export PATH="$HOME/.nvm/versions/node/$LATEST_NVM/bin:$PATH"
  fi
fi

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Remove macOS Gatekeeper quarantine attributes if present
xattr -cr "$DIR" 2>/dev/null || true

echo "========================================================"
echo "  Open MusicFlow Studio — LG SJ8 Controller & DMS"
echo "  Web UI & API : http://127.0.0.1:4741"
echo "  DLNA / DMS   : http://0.0.0.0:49252/dmr.xml"
echo "========================================================"

if nc -z 127.0.0.1 4741 >/dev/null 2>&1; then
  echo "Server is already running on port 4741! Opening browser..."
  open "http://127.0.0.1:4741"
  exit 0
fi

(sleep 1 && open "http://127.0.0.1:4741" || true) &
exec node "$DIR/dist-electron/backend/standaloneServer.js"
