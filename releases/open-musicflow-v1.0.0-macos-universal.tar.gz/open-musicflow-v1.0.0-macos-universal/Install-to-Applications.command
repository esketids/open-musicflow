#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Open MusicFlow Studio.app"
TARGET_DIR="/Applications"
if [ ! -w "$TARGET_DIR" ]; then
  TARGET_DIR="$HOME/Applications"
  mkdir -p "$TARGET_DIR"
fi

echo "Installing '$APP_NAME' to $TARGET_DIR ..."
xattr -cr "$DIR/$APP_NAME" 2>/dev/null || true
rm -rf "$TARGET_DIR/$APP_NAME"
cp -R "$DIR/$APP_NAME" "$TARGET_DIR/$APP_NAME"
xattr -cr "$TARGET_DIR/$APP_NAME" 2>/dev/null || true

echo "✅ Installed '$TARGET_DIR/$APP_NAME'!"
echo "Launching Open MusicFlow Studio..."
open "$TARGET_DIR/$APP_NAME"
